from database import Database
import logging


def setup_database():
    logging.basicConfig(level=logging.INFO)

    db = Database()

    print("Database setup completed successfully! - setup.py:10")
    print("Superuser credentials: - setup.py:11")
    print("Username: admin - setup.py:12")
    print("Password: admin123 - setup.py:13")


if __name__ == "__main__":
    setup_database()
