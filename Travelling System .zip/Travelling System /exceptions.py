class InsufficientBalanceError(Exception):
    pass


class TripNotAvailableError(Exception):
    pass


class UserAlreadyExistsError(Exception):
    pass


class AuthenticationError(Exception):
    pass