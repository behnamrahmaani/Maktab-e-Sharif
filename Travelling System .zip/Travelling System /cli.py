import sys
from datetime import datetime
from models import User, Admin
from exceptions import *


class BusTerminalCLI:
    def __init__(self):
        self.current_user = None

    def display_main_menu(self):
        print("\n - cli.py:12" + "=" * 50)
        print("BUS TERMINAL MANAGEMENT SYSTEM - cli.py:13")
        print("= - cli.py:14" * 50)
        print("1. User Registration - cli.py:15")
        print("2. User Login - cli.py:16")
        print("3. Admin Login - cli.py:17")
        print("4. View Available Trips - cli.py:18")
        print("5. Exit - cli.py:19")
        print("= - cli.py:20" * 50)

    def display_user_menu(self):
        print("\n - cli.py:23" + "=" * 50)
        print(f"USER DASHBOARD  Welcome {self.current_user.username}! - cli.py:24")
        print("= - cli.py:25" * 50)
        print("1. View Wallet Balance - cli.py:26")
        print("2. Increase Wallet Balance - cli.py:27")
        print("3. View Available Trips - cli.py:28")
        print("4. Purchase Ticket - cli.py:29")
        print("5. View Trip History - cli.py:30")
        print("6. Change Password - cli.py:31")
        print("7. Logout - cli.py:32")
        print("= - cli.py:33" * 50)

    def display_admin_menu(self):
        print("\n - cli.py:36" + "=" * 50)
        print("ADMIN DASHBOARD - cli.py:37")
        print("= - cli.py:38" * 50)
        print("1. Create Trip - cli.py:39")
        print("2. View All Trips - cli.py:40")
        print("3. Update Trip - cli.py:41")
        print("4. Delete Trip - cli.py:42")
        print("5. View All Users - cli.py:43")
        print("6. Logout - cli.py:44")
        print("= - cli.py:45" * 50)

    def run(self):
        while True:
            if not self.current_user:
                self.main_menu()
            else:
                if self.current_user.is_superuser:
                    self.admin_menu()
                else:
                    self.user_menu()

    def main_menu(self):
        self.display_main_menu()
        choice = input("Enter your choice (1-5): ").strip()

        try:
            if choice == "1":
                self.user_registration()
            elif choice == "2":
                self.user_login()
            elif choice == "3":
                self.admin_login()
            elif choice == "4":
                self.view_available_trips()
            elif choice == "5":
                print("Thank you for using Bus Terminal System. Goodbye! - cli.py:71")
                sys.exit(0)
            else:
                print("Invalid choice. Please try again. - cli.py:74")
        except Exception as e:
            print(f"Error: {e} - cli.py:76")

    def user_registration(self):
        print("\n User Registration - cli.py:79")
        username = input("Enter username: ").strip()
        password = input("Enter password: ").strip()

        if not username or not password:
            print("Username and password are required! - cli.py:84")
            return

        try:
            self.current_user = User.register(username, password)
            print("Registration successful! You are now logged in. - cli.py:89")
        except UserAlreadyExistsError as e:
            print(f"{e} - cli.py:91")
        except Exception as e:
            print(f"Registration failed: {e} - cli.py:93")

    def user_login(self):
        print("\n User Login - cli.py:96")
        username = input("Username: ").strip()
        password = input("Password: ").strip()

        try:
            self.current_user = User.login(username, password)
            print("Login successful! - cli.py:102")
        except AuthenticationError as e:
            print(f"{e} - cli.py:104")
        except Exception as e:
            print(f"Login failed: {e} - cli.py:106")

    def admin_login(self):
        print("\n Admin Login - cli.py:109")
        username = input("Username: ").strip()
        password = input("Password: ").strip()

        try:
            user = User.login(username, password)
            if user.is_superuser:
                self.current_user = Admin(user.__dict__)
                print("Admin login successful! - cli.py:117")
            else:
                print("Access denied. Admin privileges required. - cli.py:119")
                self.current_user = None
        except AuthenticationError as e:
            print(f"{e} - cli.py:122")
        except Exception as e:
            print(f"Login failed: {e} - cli.py:124")

    def view_available_trips(self):
        print("\n Available Trips - cli.py:127")
        try:
            if self.current_user:
                trips = self.current_user.get_available_trips()
            else:
                # Create temporary user instance to access the method
                temp_user = User(
                    {
                        "id": None,
                        "username": "",
                        "wallet_balance": 0,
                        "is_superuser": False,
                    }
                )
                trips = temp_user.get_available_trips()

            if not trips:
                print("No available trips found. - cli.py:144")
                return

            for trip in trips:
                print(
                    f"ID: {trip['id']} | Cost: ${trip['cost']} |"
                    f"Start: {trip['start_time']} | End: {trip['end_time']}"
                )
        except Exception as e:
            print(f"Error fetching trips: {e} - cli.py:153")

    def user_menu(self):
        self.display_user_menu()
        choice = input("Enter your choice (1-7): ").strip()

        try:
            if choice == "1":
                self.view_wallet_balance()
            elif choice == "2":
                self.increase_wallet_balance()
            elif choice == "3":
                self.view_available_trips()
            elif choice == "4":
                self.purchase_ticket()
            elif choice == "5":
                self.view_trip_history()
            elif choice == "6":
                self.change_password()
            elif choice == "7":
                print("Logging out... - cli.py:173")
                self.current_user = None
            else:
                print("Invalid choice. Please try again. - cli.py:176")
        except Exception as e:
            print(f"Error: {e} - cli.py:178")

    def admin_menu(self):
        self.display_admin_menu()
        choice = input("Enter your choice (1-6): ").strip()

        try:
            if choice == "1":
                self.create_trip()
            elif choice == "2":
                self.view_all_trips()
            elif choice == "3":
                self.update_trip()
            elif choice == "4":
                self.delete_trip()
            elif choice == "5":
                self.view_all_users()
            elif choice == "6":
                print("Logging out... - cli.py:196")
                self.current_user = None
            else:
                print("Invalid choice. Please try again. - cli.py:199")
        except Exception as e:
            print(f"Error: {e} - cli.py:201")

    def view_wallet_balance(self):
        print(
            f"\n Your current wallet balance: ${self.current_user.wallet_balance:.2f}"
        )

    def increase_wallet_balance(self):
        try:
            amount = float(input("Enter amount to add: $"))
            if amount <= 0:
                print("Amount must be positive. - cli.py:212")
                return

            self.current_user.increase_balance(amount)
            print(
                f" ${amount:.2f} added to your wallet. New balance: ${self.current_user.wallet_balance:.2f}"
            )
        except ValueError:
            print("Invalid amount. Please enter a valid number. - cli.py:220")

    def purchase_ticket(self):
        self.view_available_trips()
        try:
            trip_id = int(input("Enter trip ID to purchase: "))
            self.current_user.purchase_ticket(trip_id)
            print("Ticket purchased successfully! - cli.py:227")
        except (InsufficientBalanceError, TripNotAvailableError) as e:
            print(f"{e} - cli.py:229")
        except ValueError:
            print("Invalid trip ID. - cli.py:231")
        except Exception as e:
            print(f"Purchase failed: {e} - cli.py:233")

    def view_trip_history(self):
        print("\n Your Trip History - cli.py:236")
        try:
            trips = self.current_user.get_trip_history()
            if not trips:
                print("No trip history found. - cli.py:240")
                return

            for trip in trips:
                print(
                    f"Trip ID: {trip['trip_id']} | Cost: ${trip['cost']} |"
                    f"Start: {trip['start_time']} | Purchased: {trip['purchase_time']}"
                )
        except Exception as e:
            print(f"Error fetching trip history: {e} - cli.py:249")

    def change_password(self):
        new_password = input("Enter new password: ").strip()
        if not new_password:
            print("Password cannot be empty. - cli.py:254")
            return

        confirm = input("Confirm new password: ").strip()
        if new_password != confirm:
            print("Passwords do not match. - cli.py:259")
            return

        self.current_user.change_password(new_password)
        print("Password changed successfully! - cli.py:263")

    def create_trip(self):
        print("\n Create New Trip - cli.py:266")
        try:
            cost = float(input("Enter trip cost: $"))
            start_time = input("Enter start time (YYYY-MM-DD HH:MM:SS): ")
            end_time = input("Enter end time (YYYY-MM-DD HH:MM:SS): ")

            # Validate datetime format
            datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
            datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")

            self.current_user.create_trip(cost, start_time, end_time)
            print("Trip created successfully! - cli.py:277")
        except ValueError as e:
            print(f"Invalid input: {e} - cli.py:279")
        except Exception as e:
            print(f"Failed to create trip: {e} - cli.py:281")

    def view_all_trips(self):
        print("\n All Trips - cli.py:284")
        try:
            trips = self.current_user.get_all_trips()
            if not trips:
                print("No trips found. - cli.py:288")
                return

            for trip in trips:
                status = "Active" if trip["is_active"] else "Inactive"
                print(
                    f"ID: {trip['id']} | Cost: ${trip['cost']} |"
                    f"Start: {trip['start_time']} | End: {trip['end_time']} | Status: {status}"
                )
        except Exception as e:
            print(f"Error fetching trips: {e} - cli.py:298")

    def update_trip(self):
        self.view_all_trips()
        try:
            trip_id = int(input("Enter trip ID to update: "))

            print("Leave blank to keep current value: - cli.py:305")
            cost = input("New cost (or blank): ").strip()
            start_time = input(
                "New start time (YYYY-MM-DD HH:MM:SS or blank): "
            ).strip()
            end_time = input("New end time (YYYY-MM-DD HH:MM:SS or blank): ").strip()
            is_active = input("Set active? (true/false/blank): ").strip().lower()

            # Convert inputs
            cost = float(cost) if cost else None
            is_active = {"true": True, "false": False}.get(is_active, None)

            self.current_user.update_trip(
                trip_id, cost, start_time or None, end_time or None, is_active
            )
            print("Trip updated successfully! - cli.py:320")
        except ValueError as e:
            print(f"Invalid input: {e} - cli.py:322")
        except Exception as e:
            print(f"Failed to update trip: {e} - cli.py:324")

    def delete_trip(self):
        self.view_all_trips()
        try:
            trip_id = int(input("Enter trip ID to delete: "))
            confirm = (
                input("Are you sure? This action cannot be undone (y/n): ")
                .strip()
                .lower()
            )

            if confirm == "y":
                self.current_user.delete_trip(trip_id)
                print("Trip deleted successfully! - cli.py:338")
            else:
                print("Deletion cancelled. - cli.py:340")
        except ValueError:
            print("Invalid trip ID. - cli.py:342")
        except Exception as e:
            print(f"Failed to delete trip: {e} - cli.py:344")

    def view_all_users(self):
        print("\n All Users - cli.py:347")
        try:
            users = self.current_user.get_all_users()
            if not users:
                print("No users found. - cli.py:351")
                return

            for user in users:
                print(
                    f"ID: {user['id']} | Username: {user['username']} |"
                    f"Balance: ${user['wallet_balance']:.2f} | Joined: {user['created_at']}"
                )
        except Exception as e:
            print(f"Error fetching users: {e} - cli.py:360")


if __name__ == "__main__":
    cli = BusTerminalCLI()
    cli.run()
