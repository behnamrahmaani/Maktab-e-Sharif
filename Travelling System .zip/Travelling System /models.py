from datetime import datetime
from database import Database
from exceptions import *


class User:
    def __init__(self, user_data):
        self.id = user_data["id"]
        self.username = user_data["username"]
        self.wallet_balance = float(user_data["wallet_balance"])
        self.is_superuser = user_data["is_superuser"]

    @classmethod
    def register(cls, username, password):
        db = Database()

        # Check if user exists
        existing_user = db.execute_query(
            "SELECT id FROM users WHERE username = %s", (username,), fetch=True
        )

        if existing_user:
            raise UserAlreadyExistsError("Username already exists")

        # Create new user
        db.execute_query(
            "INSERT INTO users (username, password_hash) VALUES (%s, %s)",
            (username, password),
        )

        # Log the action
        db.execute_query(
            "INSERT INTO system_logs (action, details) VALUES (%s, %s)",
            ("USER_REGISTER", f"New user registered: {username}"),
        )

        return cls.login(username, password)

    @classmethod
    def login(cls, username, password):
        db = Database()

        user_data = db.execute_query(
            "SELECT id, username, wallet_balance, is_superuser FROM users WHERE username = %s AND password_hash = %s",
            (username, password),
            fetch=True,
        )

        if not user_data:
            raise AuthenticationError("Invalid username or password")

        # Log the action
        db.execute_query(
            "INSERT INTO system_logs (user_id, action) VALUES (%s, %s)",
            (user_data[0]["id"], "USER_LOGIN"),
        )

        return cls(user_data[0])

    def increase_balance(self, amount):
        db = Database()

        db.execute_query(
            "UPDATE users SET wallet_balance = wallet_balance + %s WHERE id = %s",
            (amount, self.id),
        )

        db.execute_query(
            "INSERT INTO transactions (user_id, amount, transaction_type, description) VALUES (%s, %s, %s, %s)",
            (self.id, amount, "topup", f"Wallet top-up: +{amount}"),
        )

        db.execute_query(
            "INSERT INTO system_logs (user_id, action, details) VALUES (%s, %s, %s)",
            (self.id, "WALLET_TOPUP", f"Amount: {amount}"),
        )

        self.wallet_balance += amount

    def get_trip_history(self):
        db = Database()

        trips = db.execute_query(
            """
            SELECT t.*, tr.cost, tr.start_time, tr.end_time 
            FROM tickets t 
            JOIN trips tr ON t.trip_id = tr.id 
            WHERE t.user_id = %s 
            ORDER BY t.purchase_time DESC
        """,
            (self.id,),
            fetch=True,
        )

        return trips

    def get_available_trips(self):
        db = Database()

        trips = db.execute_query(
            """
            SELECT * FROM trips 
            WHERE start_time > NOW() AND is_active = TRUE
            ORDER BY start_time ASC
        """,
            fetch=True,
        )

        return trips

    def purchase_ticket(self, trip_id):
        db = Database()

        # Get trip details
        trip_data = db.execute_query(
            "SELECT * FROM trips WHERE id = %s AND is_active = TRUE",
            (trip_id,),
            fetch=True,
        )

        if not trip_data:
            raise TripNotAvailableError("Trip not found or not available")

        trip = trip_data[0]

        # Check if trip has started
        if datetime.now() >= trip["start_time"]:
            raise TripNotAvailableError(
                "Trip has already started, cannot purchase ticket"
            )

        # Check balance
        if self.wallet_balance < trip["cost"]:
            raise InsufficientBalanceError("Insufficient balance to purchase ticket")

        # Process purchase
        db.execute_query(
            "UPDATE users SET wallet_balance = wallet_balance - %s WHERE id = %s",
            (trip["cost"], self.id),
        )

        # Create ticket
        db.execute_query(
            "INSERT INTO tickets (user_id, trip_id) VALUES (%s, %s)", (self.id, trip_id)
        )

        # Record transaction
        db.execute_query(
            "INSERT INTO transactions (user_id, amount, transaction_type, description) VALUES (%s, %s, %s, %s)",
            (self.id, -trip["cost"], "purchase", f"Ticket purchase for trip {trip_id}"),
        )

        # Log the action
        db.execute_query(
            "INSERT INTO system_logs (user_id, action, details) VALUES (%s, %s, %s)",
            (self.id, "TICKET_PURCHASE", f"Trip: {trip_id}, Cost: {trip['cost']}"),
        )

        self.wallet_balance -= trip["cost"]

    def change_password(self, new_password):
        db = Database()

        db.execute_query(
            "UPDATE users SET password_hash = %s WHERE id = %s", (new_password, self.id)
        )

        db.execute_query(
            "INSERT INTO system_logs (user_id, action) VALUES (%s, %s)",
            (self.id, "PASSWORD_CHANGE"),
        )


class Admin(User):
    def create_trip(self, cost, start_time, end_time):
        db = Database()

        db.execute_query(
            "INSERT INTO trips (cost, start_time, end_time) VALUES (%s, %s, %s)",
            (cost, start_time, end_time),
        )

        db.execute_query(
            "INSERT INTO system_logs (user_id, action, details) VALUES (%s, %s, %s)",
            (self.id, "TRIP_CREATE", f"Cost: {cost}, Start: {start_time}"),
        )

    def update_trip(
        self, trip_id, cost=None, start_time=None, end_time=None, is_active=None
    ):
        db = Database()

        updates = []
        params = []

        if cost is not None:
            updates.append("cost = %s")
            params.append(cost)
        if start_time is not None:
            updates.append("start_time = %s")
            params.append(start_time)
        if end_time is not None:
            updates.append("end_time = %s")
            params.append(end_time)
        if is_active is not None:
            updates.append("is_active = %s")
            params.append(is_active)

        if updates:
            params.append(trip_id)
            query = f"UPDATE trips SET {', '.join(updates)} WHERE id = %s"
            db.execute_query(query, params)

            db.execute_query(
                "INSERT INTO system_logs (user_id, action, details) VALUES (%s, %s, %s)",
                (self.id, "TRIP_UPDATE", f"Trip: {trip_id}"),
            )

    def delete_trip(self, trip_id):
        db = Database()

        db.execute_query("DELETE FROM trips WHERE id = %s", (trip_id,))

        db.execute_query(
            "INSERT INTO system_logs (user_id, action, details) VALUES (%s, %s, %s)",
            (self.id, "TRIP_DELETE", f"Trip: {trip_id}"),
        )

    def get_all_users(self):
        db = Database()

        users = db.execute_query(
            "SELECT id, username, wallet_balance, created_at FROM users WHERE is_superuser = FALSE",
            fetch=True,
        )

        return users

    def get_all_trips(self):
        db = Database()

        trips = db.execute_query(
            "SELECT * FROM trips ORDER BY start_time ASC", fetch=True
        )

        return trips
