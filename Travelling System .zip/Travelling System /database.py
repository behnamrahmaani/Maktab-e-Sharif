import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config
import logging


class Database:
    def __init__(self):
        self.config = Config()
        self.connection = None
        self.connect()
        self.init_database()

    def connect(self):
        try:
            self.connection = psycopg2.connect(
                host=self.config.DB_HOST,
                port=self.config.DB_PORT,
                database=self.config.DB_NAME,
                user=self.config.DB_USER,
                password=self.config.DB_PASSWORD,
            )
            logging.info("Connected to database successfully - database.py:22")
        except Exception as e:
            logging.error(f"Database connection failed: {e} - database.py:24")
            raise

    def init_database(self):
        """Initialize database with required tables and superuser"""
        try:
            cursor = self.connection.cursor()

            # Create superuser if not exists
            cursor.execute(
                """
                INSERT INTO users (username, password_hash, is_superuser) 
                VALUES (%s, %s, %s)
                ON CONFLICT (username) DO NOTHING
            """,
                (self.config.SUPERUSER_USERNAME, self.config.SUPERUSER_PASSWORD, True),
            )

            self.connection.commit()
            cursor.close()

        except Exception as e:
            logging.error(f"Database initialization failed: {e}")
            self.connection.rollback()

    def execute_query(self, query, params=None, fetch=False):
        try:
            cursor = self.connection.cursor(cursor_factory=RealDictCursor)
            cursor.execute(query, params or ())

            if fetch:
                result = cursor.fetchall()
            else:
                result = None

            self.connection.commit()
            cursor.close()
            return result

        except Exception as e:
            self.connection.rollback()
            logging.error(f"Query execution failed: {e}")
            raise
