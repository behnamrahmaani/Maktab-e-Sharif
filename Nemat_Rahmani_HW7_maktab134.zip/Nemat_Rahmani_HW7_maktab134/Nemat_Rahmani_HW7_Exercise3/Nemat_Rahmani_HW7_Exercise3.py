from abc import ABC, abstractmethod


class InvalidEmailError(Exception):

    def __init__(self, email, message="The Entered Email is not Valid"):
        self.email = email
        self.message = message
        super().__init__(f"{message} ({email})")


class ValidationMixin:
    def validate_email(self, email):
        if "@" not in email or "." not in email:
            raise InvalidEmailError(email)
        return True


class BaseUser(ABC):
    def __init__(self, name, email):
        self.name = name
        self.email = email

    @abstractmethod
    def get_role(self):
        pass


class AdminUser(BaseUser, ValidationMixin):
    def __init__(self, name, email):
        self.validate_email(email)  # بررسی صحت ایمیل
        super().__init__(name, email)

    def get_role(self):
        return "Admin"


class CustomerUser(BaseUser, ValidationMixin):
    def __init__(self, name, email):
        self.validate_email(email)
        super().__init__(name, email)

    def get_role(self):
        return "Customer"


# Testing Phase
try:
    user1 = AdminUser("Ali", "ali@example.com")
    print(f"{user1.name} -> {user1.get_role()} -> {user1.email}")

    user2 = CustomerUser("Reza", "reza#example.com")
    print(f"{user2.name} -> {user2.get_role()} -> {user2.email}")

except InvalidEmailError as e:
    print("Error: ", e)