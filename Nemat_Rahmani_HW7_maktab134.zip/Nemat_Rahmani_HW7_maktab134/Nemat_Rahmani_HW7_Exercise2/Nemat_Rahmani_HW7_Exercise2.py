import random


class Student:
    def __init__(self, age, height, weight):
        self.age = age
        self.height = height
        self.weight = weight


def generate_school_data(school_name, count):
    students = []
    print(f"Random Data Generating for {school_name} ({count} Students):")
    for i in range(count):
        age = random.randint(6, 18)
        height = round(random.uniform(110, 190), 1)
        weight = round(random.uniform(20, 80), 1)
        students.append(Student(age, height, weight))
        print(f"{i+1}. Age: {age} - Height: {height} - Weight: {weight}")
    print()
    return students


def calc_avg(students):
    total_age = sum(s.age for s in students)
    total_height = sum(s.height for s in students)
    total_weight = sum(s.weight for s in students)
    n = len(students)
    return total_age / n, total_height / n, total_weight / n


count_a = 15
count_b = 20


school_a = generate_school_data("School A", count_a)
school_b = generate_school_data("School B", count_b)


avg_age_a, avg_height_a, avg_weight_a = calc_avg(school_a)
avg_age_b, avg_height_b, avg_weight_b = calc_avg(school_b)


print(f"{avg_age_a:.2f}")
print(f"{avg_height_a:.2f}")
print(f"{avg_weight_a:.2f}")
print(f"{avg_age_b:.2f}")
print(f"{avg_height_b:.2f}")
print(f"{avg_weight_b:.2f}")


if avg_height_a > avg_height_b:
    print("School A")
elif avg_height_b > avg_height_a:
    print("School B")
else:
    if avg_weight_a < avg_weight_b:
        print("School A")
    elif avg_weight_b < avg_weight_a:
        print("School B")
    else:
        print("Same")
