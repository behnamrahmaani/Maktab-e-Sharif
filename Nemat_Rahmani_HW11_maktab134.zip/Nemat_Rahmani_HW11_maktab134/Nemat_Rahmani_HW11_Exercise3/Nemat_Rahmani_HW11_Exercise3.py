import requests
import logging
from datetime import datetime
from typing import List, Dict, Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("sports_activities.log"), logging.StreamHandler()],
)


class Athlete:
    def __init__(self, name: str, age: int, city: str):
        self.name = name
        self.age = age
        self.city = city
        self.activities = []
        logging.info(f"New athlete created: {name}")

    def add_activity(
        self,
        activity_type: str,
        value: float,
        date_time: str,
        weather_check: bool = True,
    ):
        try:
            activity_date = datetime.strptime(date_time, "%Y-%m-%d %H:%M:%S")

            weather_warning = None
            if weather_check and activity_type.lower() == "running":
                weather_status = self.check_weather(activity_date)
                if weather_status and "rain" in weather_status.lower():
                    weather_warning = f"Warning: Rainy weather - {weather_status}"
                    logging.warning(f"Weather alert for {self.name}: {weather_warning}")

            activity = {
                "type": activity_type,
                "value": value,
                "date_time": date_time,
                "weather_warning": weather_warning,
            }

            self.activities.append(activity)
            logging.info(
                f"Activity recorded for {self.name}: {activity_type} for {value}"
            )

            return True, weather_warning

        except ValueError as e:
            error_msg = f"Date format error: {e}"
            logging.error(error_msg)
            return False, error_msg
        except Exception as e:
            error_msg = f"Unknown error: {e}"
            logging.error(error_msg)
            return False, error_msg

    def check_weather(self, date: datetime) -> Optional[str]:
        try:
            API_KEY = "d83165313ddea9c062d9625c8faf5298"
            url = f"http://api.openweathermap.org/data/2.5/weather?q={self.city}&appid={API_KEY}&units=metric"

            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                weather_description = data["weather"][0]["description"]
                return weather_description
            else:
                logging.error(f"Error getting weather: {response.status_code}")
                return None

        except Exception as e:
            logging.error(f"API connection error: {e}")
            return None

    def get_activities_summary(self) -> Dict:
        """Get summary of athlete's activities"""
        total_distance = 0
        total_duration = 0

        for activity in self.activities:
            if activity["type"] in ["running", "cycling"]:
                total_distance += activity["value"]
            else:
                total_duration += activity["value"]

        return {
            "total_activities": len(self.activities),
            "total_distance": total_distance,
            "total_duration": total_duration,
        }

    def display_activities(self):
        """Display all athlete activities"""
        print(f"\nActivities for {self.name}:")
        for i, activity in enumerate(self.activities, 1):
            print(
                f"{i}. Type: {activity['type']}, Value: {activity['value']}, Date: {activity['date_time']}"
            )
            if activity["weather_warning"]:
                print(f"   Warning: {activity['weather_warning']}")

        summary = self.get_activities_summary()
        print(
            f"\nSummary: {summary['total_activities']} activities, Total distance: {summary['total_distance']} km, Total time: {summary['total_duration']} min"
        )


class SportsActivityManager:
    def __init__(self):
        self.athletes = {}
        logging.info("Sports activity management system started")

    def add_athlete(self, name: str, age: int, city: str) -> bool:
        if name in self.athletes:
            logging.warning(f"Athlete with name {name} already exists")
            return False

        self.athletes[name] = Athlete(name, age, city)
        return True

    def get_athlete(self, name: str) -> Optional[Athlete]:
        return self.athletes.get(name)

    def list_athletes(self):
        print("\nAthletes list:")
        for name, athlete in self.athletes.items():
            print(f"{name} ({athlete.age} years) - {athlete.city}")


# Testing Phase
if __name__ == "__main__":
    manager = SportsActivityManager()
    manager.add_athlete("Ali", 25, "Tehran")
    manager.add_athlete("Maryam", 30, "Isfahan")

    ali = manager.get_athlete("Ali")
    if ali:
        ali.add_activity("running", 5.2, "2024-09-23 08:30:00")
        ali.add_activity("swimming", 45, "2024-09-24 10:00:00")

    maryam = manager.get_athlete("Maryam")
    if maryam:
        maryam.add_activity("cycling", 15.7, "2024-09-23 17:30:00")
        maryam.add_activity("running", 3.8, "2024-09-24 07:15:00")

    manager.list_athletes()

    if ali:
        ali.display_activities()

    if maryam:
        maryam.display_activities()
