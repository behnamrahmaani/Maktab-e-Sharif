import requests

class MovieAPIManager:
    def __init__(self):
        self.session = None
        self.base_url = "https://fake-movies-api.com"

    def __enter__(self):
        self.session = requests.Session()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            self.session.close()

    def get_movies(self):
        try:
            response = self.session.get(f"{self.base_url}/movies")
            response.raise_for_status()
            movies = response.json()
            for movie in movies:
                print(f"Title: {movie.get('title', 'N/A')} | Year: {movie.get('year', 'N/A')}")
        except requests.RequestException as e:
            print(f"Error fetching movies: {e}")

    def add_movie(self, movie_data):
        try:
            response = self.session.post(
                f"{self.base_url}/movies",
                json=movie_data
            )
            response.raise_for_status()
            print("Movie added successfully!")
        except requests.RequestException as e:
            print(f"Error adding movie: {e}")

def main():
    with MovieAPIManager() as manager:
        print("Existing Movies:")
        manager.get_movies()
        
        print("\nAdd New Movie:")
        new_movie = {
            "title": input("Enter movie title: "),
            "year": input("Enter release year: "),
            "genre": input("Enter genre: "),
            "plot": input("Enter plot summary: ")
        }
        
        manager.add_movie(new_movie)

if __name__ == "__main__":
    main()