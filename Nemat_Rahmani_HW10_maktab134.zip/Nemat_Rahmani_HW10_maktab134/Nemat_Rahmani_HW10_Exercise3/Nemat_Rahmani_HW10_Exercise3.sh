#!/bin/bash

# Simple Bash Calculator Script

echo "Bash Calculator"
echo "---------------"

# Read first number
read -p "Enter first number: " num1

# Read second number
read -p "Enter second number: " num2

# Read operation choice
read -p "Choose operation (+, -, *, /): " operation

# Perform calculation based on operation
case $operation in
    "+")
        result=$(echo "$num1 + $num2" | bc -l)
        ;;
    "-")
        result=$(echo "$num1 - $num2" | bc -l)
        ;;
    "*")
        result=$(echo "$num1 * $num2" | bc -l)
        ;;
    "/")
        # Check for division by zero
        if [ "$num2" -eq 0 ] 2>/dev/null; then
            echo "Error: Division by zero is not allowed."
            exit 1
        fi
        result=$(echo "scale=2; $num1 / $num2" | bc -l)
        ;;
    *)
        echo "Error: Invalid operation. Please choose from +, -, *, /"
        exit 1
        ;;
esac

# Display the result
echo "Result: $result"

# Save to results.txt
echo "$(date): $num1 $operation $num2 = $result" >> results.txt
echo "Saved to results.txt"