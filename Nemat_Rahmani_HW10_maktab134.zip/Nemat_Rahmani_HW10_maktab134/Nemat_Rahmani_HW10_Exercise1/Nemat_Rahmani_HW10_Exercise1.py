from abc import ABC, abstractmethod
from datetime import date
import pickle
import re


class Activity(ABC):

    def __init__(self, activity_type: str, calories: int, date: date):
        self._type = activity_type
        self._calories = calories
        self._date = date

    @abstractmethod
    def get_details(self):
        pass

    @property
    def calories(self):
        return self._calories

    @property
    def date(self):
        return self._date

    @property
    def type(self):
        return self._type


class Workout(Activity):

    def __init__(self, workout_type: str, duration: int, calories: int, date: date):
        super().__init__(workout_type, calories, date)
        self._duration = duration

    def get_details(self):
        return f"تمرین {self._type} به مدت {self._duration} دقیقه، {self._calories} کالری سوزانده"

    @property
    def duration(self):
        return self._duration


class Meal(Activity):

    def __init__(self, meal_type: str, calories: int, date: date):
        super().__init__(meal_type, calories, date)

    def get_details(self) -> str:
        return f"وعده {self._type}، {self._calories} کالری دریافت شده"


class User:

    def __init__(self, name: str, email: str):
        self._name = name
        self._email = email
        self._activities = []

    def add_activity(self, activity: Activity):
        self._activities.append(activity)

    def get_activities_by_date(self, target_date: date):
        return [
            activity for activity in self._activities if activity.date == target_date
        ]

    def get_progress_report(self, start_date: date = None, end_date: date = None):
        filtered_activities = self._activities

        if start_date and end_date:
            filtered_activities = [
                activity
                for activity in self._activities
                if start_date <= activity.date <= end_date
            ]

        total_burned = sum(
            activity.calories
            for activity in filtered_activities
            if isinstance(activity, Workout)
        )
        total_consumed = sum(
            activity.calories
            for activity in filtered_activities
            if isinstance(activity, Meal)
        )
        net_calories = total_consumed - total_burned

        return {
            "user": self._name,
            "total_burned": total_burned,
            "total_consumed": total_consumed,
            "net_calories": net_calories,
        }

    @property
    def email(self):
        return self._email

    @property
    def name(self):
        return self._name

    def __eq__(self, other):
        if isinstance(other, User):
            return self._email == other.email
        return False


class FitnessTracker:

    def __init__(self):
        self._users = {}

    def register_user(self, user: User):
        if user.email in self._users:
            raise UserAlreadyExistsError(
                f"کاربر با ایمیل {user.email} قبلاً ثبت نام کرده است"
            )
        self._users[user.email] = user

    def log_workout(self, email: str, workout: Workout):
        if email not in self._users:
            raise UserNotFoundError(f"کاربر با ایمیل {email} یافت نشد")
        self._users[email].add_activity(workout)

    def log_meal(self, email: str, meal: Meal):
        if email not in self._users:
            raise UserNotFoundError(f"کاربر با ایمیل {email} یافت نشد")
        self._users[email].add_activity(meal)

    def get_report(self, email: str):
        if email not in self._users:
            raise UserNotFoundError(f"کاربر با ایمیل {email} یافت نشد")
        return self._users[email].get_progress_report()

    def save_data(self, filename: str):
        with open(filename, "wb") as file:
            pickle.dump(self._users, file)

    def load_data(self, filename: str):
        with open(filename, "rb") as file:
            self._users = pickle.load(file)


def validate_email(email: str):
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None


def validate_activity_type(activity_type: str):
    pattern = r"^[a-zA-Z\s]{2,50}$"
    return re.match(pattern, activity_type) is not None


# Testing Phase
def main():
    tracker = FitnessTracker()

    user1 = User("Behnam", "behnam@example.com")
    user2 = User("Mehdi", "mehdi@example.com")

    tracker.register_user(user1)
    tracker.register_user(user2)

    tracker.log_workout("behnam@example.com", Workout("Running", 30, 300, date.today()))
    tracker.log_workout("behnam@example.com", Workout("Yoga", 45, 200, date.today()))
    tracker.log_workout("mehdi@example.com", Workout("Cycling", 60, 500, date.today()))

    tracker.log_meal("behnam@example.com", Meal("Breakfast", 400, date.today()))
    tracker.log_meal("behnam@example.com", Meal("Lunch", 600, date.today()))
    tracker.log_meal("mehdi@example.com", Meal("Dinner", 800, date.today()))

    print(tracker.get_report("behnam@example.com"))
    print(tracker.get_report("mehdi@example.com"))

    tracker.save_data("fitness_data.pkl")

    new_tracker = FitnessTracker()
    new_tracker.load_data("fitness_data.pkl")

    print(new_tracker.get_report("behnam@example.com"))
    print(new_tracker.get_report("mehdi@example.com"))


if __name__ == "__main__":
    main()
