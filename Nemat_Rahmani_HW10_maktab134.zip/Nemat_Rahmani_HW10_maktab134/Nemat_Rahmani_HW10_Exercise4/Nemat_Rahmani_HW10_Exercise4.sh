#!/bin/bash

read -p "Enter directory path: " dir_path

if [ -d "$dir_path" ]; then
    echo "Directory exists."
    
    # Count files and directories
    files_count=0
    dirs_count=0
    for item in "$dir_path"/*; do
        if [ -f "$item" ]; then
            ((files_count++))
        elif [ -d "$item" ]; then
            ((dirs_count++))
        fi
    done
    echo "Total files: $files_count"
    echo "Total directories: $dirs_count"
    
    # Show top 5 largest files
    echo "Top 5 largest files:"
    ls -lhS "$dir_path" | grep -v '^total' | head -n 5 | while read -r line; do
        echo "- $line"
    done
else
    echo "Error: Directory does not exist."
fi