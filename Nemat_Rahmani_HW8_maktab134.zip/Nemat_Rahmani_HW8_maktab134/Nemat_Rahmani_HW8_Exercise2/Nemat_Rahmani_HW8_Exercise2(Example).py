from abc import ABC, abstractmethod

# Case 1 :Defining a class with "abstract method" and not inheriting from an "ABC (Abstract Base Class)"
class NormalClass:
    @abstractmethod
    def do_something(self):
        pass

# In "Case 1", we can instantiate (creat an object) directly without raising any errors
n = NormalClass()
print("NormalClass instance created!")

# In "Case 1", calling the method will raise a TypeError
try:
    n.do_something()
except TypeError as e:
    print("Error calling abstract method in NormalClass:", e)


# Case 2 :Defining another class with "abstract method" and inheriting from an "ABC (Abstract Base Class)"
class AbstractClass(ABC):
    @abstractmethod
    def do_something(self):
        pass

# In "Case 2", directly instantiating will raise a TypeError
try:
    a = AbstractClass()
except TypeError as e:
    print("Error instantiating AbstractClass:", e)


# (Case 2:) Creating a subclass with no method implementation
class Child(AbstractClass):
    pass

try:
    c = Child()
except TypeError as e:
    print("Error instantiating Child:", e)


# (Case 2:) An appropriate subclass with method implementation
class RealChild(AbstractClass):
    def do_something(self):
        print("Doing something in RealChild!")

rc = RealChild()
rc.do_something()