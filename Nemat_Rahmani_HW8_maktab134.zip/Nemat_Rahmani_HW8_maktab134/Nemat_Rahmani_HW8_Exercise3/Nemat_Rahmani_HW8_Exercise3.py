from datetime import datetime
from copy import deepcopy


class BoardGameFestival:
    def __init__(self):
        self._store = {"players": {}, "games": {}, "events": {}, "logs": {}}

    def _log(self, op, by="<admin>", detail=None):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        self._store["logs"][timestamp] = {
            "op": op,
            "by": by,
            "detail": deepcopy(detail),
        }

    def add_player(self, player_id, name, email):
        if player_id in self._store["players"]:
            raise ValueError(f"Player {player_id} already exists.")
        self._store["players"][player_id] = {
            "name": name,
            "email": email,
            "registered_games": {},
        }
        self._log(
            "add_player", detail={"player_id": player_id, "name": name, "email": email}
        )

    def remove_player(self, player_id, *, force=False):
        if player_id not in self._store["players"]:
            raise ValueError(f"Player {player_id} not found.")

        for event in self._store["events"].values():
            if player_id in event["participants"]:
                if not force:
                    raise ValueError(f"Player {player_id} is registered in an event.")
                else:
                    del event["participants"][player_id]

        del self._store["players"][player_id]
        self._log("remove_player", detail={"player_id": player_id})

    def add_game(self, game_id, title, min_players, max_players, tags):
        if game_id in self._store["games"]:
            raise ValueError(f"Game {game_id} already exists.")
        tags_dict = {tag: True for tag in tags}
        self._store["games"][game_id] = {
            "title": title,
            "min_players": min_players,
            "max_players": max_players,
            "tags": tags_dict,
        }
        self._log("add_game", detail={"game_id": game_id, "title": title})

    def add_event(self, event_id, game_id, time):
        if event_id in self._store["events"]:
            raise ValueError(f"Event {event_id} already exists.")
        if game_id not in self._store["games"]:
            raise ValueError(f"Game {game_id} not found.")

        self._store["events"][event_id] = {
            "game_id": game_id,
            "time": time,
            "participants": {},
            "status": "scheduled",
        }
        self._log(
            "add_event", detail={"event_id": event_id, "game_id": game_id, "time": time}
        )

    def register_player_to_event(self, player_id, event_id, role="player"):
        if player_id not in self._store["players"]:
            raise ValueError("Player not found.")
        if event_id not in self._store["events"]:
            raise ValueError("Event not found.")

        event = self._store["events"][event_id]
        game_id = event["game_id"]
        max_players = self._store["games"][game_id]["max_players"]

        if len(event["participants"]) >= max_players:
            raise ValueError("Event is full.")

        event["participants"][player_id] = {
            "joined_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "result": "pending",
        }
        self._store["players"][player_id]["registered_games"][game_id] = {
            "role": role,
            "score": None,
        }
        self._log(
            "register_player",
            detail={"player_id": player_id, "event_id": event_id, "role": role},
        )

    def unregister_player_from_event(self, player_id, event_id):
        if event_id not in self._store["events"]:
            raise ValueError("Event not found.")
        event = self._store["events"][event_id]
        if player_id in event["participants"]:
            del event["participants"][player_id]

        game_id = event["game_id"]
        if game_id in self._store["players"][player_id]["registered_games"]:
            del self._store["players"][player_id]["registered_games"][game_id]

        self._log(
            "unregister_player", detail={"player_id": player_id, "event_id": event_id}
        )

    def record_result(self, event_id, player_id, result):
        if result not in ["win", "loss", "draw", "pending"]:
            raise ValueError("Invalid result.")
        if event_id not in self._store["events"]:
            raise ValueError("Event not found.")
        event = self._store["events"][event_id]
        if player_id not in event["participants"]:
            raise ValueError("Player not in event.")

        event["participants"][player_id]["result"] = result

        if all(p["result"] != "pending" for p in event["participants"].values()):
            event["status"] = "finished"

        self._log(
            "record_result",
            detail={"event_id": event_id, "player_id": player_id, "result": result},
        )

    def stats(self):
        num_players = len(self._store["players"])
        num_games = len(self._store["games"])
        strategy_games = sum(
            1 for g in self._store["games"].values() if g["tags"].get("strategy", False)
        )
        return {
            "players": num_players,
            "games": num_games,
            "strategy_games": strategy_games,
        }

    def get_logs(self):
        return dict(sorted(self._store["logs"].items(), key=lambda x: x[0]))


# Testing Phase ---------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    f = BoardGameFestival()

    # Adding players
    f.add_player("p1", "Ali", "ali@mail.com")
    f.add_player("p2", "Sara", "sara@mail.com")
    f.add_player("p3", "Reza", "reza@mail.com")

    # Adding games
    f.add_game("g1", "Catan", 3, 6, ["strategy", "cooperative"])
    f.add_game("g2", "Chess", 2, 2, ["strategy"])
    f.add_game("g3", "Uno", 2, 10, ["party"])

    # Adding events
    f.add_event("e1", "g1", "2025-08-20 18:00")
    f.add_event("e2", "g2", "2025-08-21 15:30")
    f.add_event("e3", "g3", "2025-08-22 19:00")

    # Registering players to events
    f.register_player_to_event("p1", "e1")
    f.register_player_to_event("p2", "e1")
    f.register_player_to_event("p3", "e1")

    f.register_player_to_event("p1", "e2")
    f.register_player_to_event("p2", "e2")

    f.register_player_to_event("p3", "e3")

    # Result recording
    f.record_result("e1", "p1", "win")
    f.record_result("e1", "p2", "loss")
    f.record_result("e1", "p3", "draw")

    f.record_result("e2", "p1", "loss")
    f.record_result("e2", "p2", "win")

    f.record_result("e3", "p3", "win")

    # Printing statistics
    print("Statistics:", f.stats())

    # Printing logs
    print("\nLogs:")
    for ts, log in f.get_logs().items():
        print(f"{ts} → {log}")
