class Move:
    def __init__(self, row: int, col: int) -> None:
        self.row = row
        self.col = col


class Board:
    def __init__(self, size: int = 3) -> None:
        self.size = size
        self._grid = [[" "] * self.size for _ in range(self.size)]

    def is_full(self) -> bool:
        return all(cell != " " for row in self._grid for cell in row)

    def place(self, move: Move, symbol: str) -> None:
        if not (0 <= move.row < self.size and 0 <= move.col < self.size):
            raise ValueError(f"Move out of bounds: row={move.row}, col={move.col}")
        if self._grid[move.row][move.col] != " ":
            raise ValueError(f"Cell already occupied: row={move.row}, col={move.col}")
        self._grid[move.row][move.col] = symbol

    def winner(self):
        lines = []
        lines.extend(self._grid)
        lines.extend(
            [[self._grid[r][c] for r in range(self.size)] for c in range(self.size)]
        )
        lines.append([self._grid[i][i] for i in range(self.size)])
        lines.append([self._grid[i][self.size - 1 - i] for i in range(self.size)])
        for line in lines:
            if line[0] != " " and all(ch == line[0] for ch in line):
                return line[0]
        return None

    def is_terminal(self) -> bool:
        return self.winner() is not None or self.is_full()

    def __str__(self) -> str:
        def hrow(idx: int) -> str:
            cells = [
                (
                    self._grid[idx][c]
                    if self._grid[idx][c] != " "
                    else str(idx * self.size + c + 1)
                )
                for c in range(self.size)
            ]
            return " | ".join(cells)

        sep = "\n" + "---+" * (self.size - 1) + "---\n"
        return sep.join(hrow(r) for r in range(self.size))


class Player:
    def __init__(self, name: str, symbol: str) -> None:
        self.name = name
        self.symbol = symbol

    def choose_move(self, board: Board) -> Move:
        raise NotImplementedError


class HumanPlayer(Player):
    def choose_move(self, board: Board) -> Move:
        while True:
            raw = input(
                f"{self.name} ({self.symbol}) – choose a cell [1-{board.size**2}]: "
            ).strip()
            if raw.lower() in {"q", "quit", "exit"}:
                raise KeyboardInterrupt
            if not raw.isdigit():
                print(f"Please enter a number between 1 and {board.size**2}.")
                continue
            pos = int(raw)
            if not 1 <= pos <= board.size**2:
                print(f"Number must be between 1 and {board.size**2}.")
                continue
            row, col = divmod(pos - 1, board.size)
            if board._grid[row][col] != " ":
                print("That cell is occupied. Try again.")
                continue
            return Move(row, col)


class Game:
    def __init__(self, p1: Player, p2: Player, size: int = 3) -> None:
        self.board = Board(size)
        self.players = (p1, p2)
        self.turn_index = 0

    @property
    def current(self) -> Player:
        return self.players[self.turn_index]

    def switch_turn(self) -> None:
        self.turn_index = 1 - self.turn_index

    def play(self) -> None:
        print(
            f"\nStarting a new {self.board.size}x{self.board.size} game! Cells are numbered 1..{self.board.size**2}:\n"
        )
        print(self.board)
        while not self.board.is_terminal():
            try:
                move = self.current.choose_move(self.board)
                self.board.place(move, self.current.symbol)
            except ValueError as e:
                print(f"Invalid move: {e}")
                continue
            except KeyboardInterrupt:
                print("\nGame aborted by user.")
                return
            print("\n" + str(self.board) + "\n")
            if self.board.winner():
                break
            self.switch_turn()

        winner = self.board.winner()
        if winner:
            print(f"🎉 Winner: {self.current.name} ({winner})\n")
        else:
            print("It's a draw! 🤝\n")


if __name__ == "__main__":
    size = input("Enter board size (default 3): ").strip()
    size = int(size) if size.isdigit() and int(size) > 0 else 3
    name1 = input("Enter Player 1 name: ").strip() or "Player 1"
    name2 = input("Enter Player 2 name: ").strip() or "Player 2"
    p1 = HumanPlayer(name1, "X")
    p2 = HumanPlayer(name2, "O")
    Game(p1, p2, size).play()
