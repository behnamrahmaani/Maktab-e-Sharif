class Product:
    def __init__(self, product_id, name, price, stock):
        self.__product_id = product_id
        self.__name = name
        self.__price = price
        self.__stock = stock

    def get_product_id(self):
        pass

    def get_name(self):
        pass

    def get_price(self):
        pass

    def get_stock(self):
        pass

    def __update_stock(self, quantity):
        pass


class CartItem:
    def __init__(self, product, quantity):
        self.__product = product
        self.__quantity = quantity

    def get_product(self):
        pass

    def get_quantity(self):
        pass

    def set_quantity(self, quantity):
        pass

    def calculate_item_total(self):
        pass


class Discount:
    def __init__(self, discount_id, discount_type, value):
        self.__discount_id = discount_id
        self.__discount_type = discount_type
        self.__value = value

    def get_discount_id(self):
        pass

    def apply_discount(self, amount):
        pass


class ShoppingCart:
    __total_items_all_carts = 0

    def __init__(self, cart_id, customer):
        self.__cart_id = cart_id
        self.__customer = customer
        self.__items = []
        self.__discount = None

    def add_item(self, product, quantity):
        pass

    def remove_item(self, product_id):
        pass

    def update_item_quantity(self, product_id, new_quantity):
        pass

    def apply_discount(self, discount):
        pass

    def calculate_total(self):
        pass

    def get_items(self):
        pass

    @classmethod
    def get_total_items_all_carts(cls):
        pass


class Customer:
    def __init__(self, customer_id, name, email):
        self.__customer_id = customer_id
        self.__name = name
        self.__email = email
        self.__shopping_cart = None

    def get_customer_id(self):
        pass

    def get_name(self):
        pass

    def get_email(self):
        pass

    def create_shopping_cart(self):
        pass

    def get_shopping_cart(self):
        pass


class InventoryManager:
    def __init__(self):
        self.__products = {}

    def add_product(self, product):
        pass

    def check_stock(self, product_id, quantity):
        pass

    def update_stock(self, product_id, quantity):
        pass

    def get_product(self, product_id):
        pass
