-- Question 5
-- Task 1: Index --> For Speeding The Search Action
CREATE INDEX idx_name ON Employees (name);

-- Task 2
-- A: Profit From Index
SELECT * FROM Employees WHERE name = 'Ali Saberi';
-- B: Without Indexing
SELECT * FROM Employees WHERE emp_id = 7;

-- Task 3
-- With Every Adding Data To Table Or Updating, The Realated Indexes Must be Updated, Too.

-- Task 4
-- Multicolumn indexes == Composite Indexes
CREATE INDEX idx_dept_salary ON Employees (department_id, salary);
