-- Question 3

ALTER TABLE Employees ADD salary INT;

UPDATE Employees
SET salary = CASE emp_id
    WHEN 1 THEN 5000
    WHEN 2 THEN 5500
    WHEN 3 THEN 5000
    WHEN 4 THEN 6500
    WHEN 5 THEN 7000
    WHEN 6 THEN 3500
    WHEN 7 THEN 4500
    WHEN 8 THEN 6000
    WHEN 9 THEN 9000
    WHEN 10 THEN 9500
    WHEN 11 THEN 10000
    WHEN 12 THEN 4500
    WHEN 13 THEN 11000
    WHEN 14 THEN 4000
    WHEN 15 THEN 12000
    WHEN 16 THEN 5000
    WHEN 17 THEN 5500
END
WHERE emp_id BETWEEN 1 AND 17;


CREATE TABLE Departments(
    department_id INT,
    dept_name VARCHAR(50)
);

INSERT INTO Departments (department_id, dept_name) VALUES 
    (1, 'IT'),
    (2, 'HR'),
    (3, 'Finance'),
    (4, 'Marketing'),
    (5, 'Sales');

-- Task 1
CREATE VIEW employee_details AS SELECT emp_id, name, department_id, salary FROM Employees;

-- Task 2
SELECT * FROM employee_details WHERE salary > 5000;

-- Task 3
-- The View Must Be Updatable For Changing Salary Directly (Here We Have A Simple Table So We Can!)
-- If We have Multiple Tables Or Complex Data, It Can Not Be Possible To Change Directly From The View.

-- Task 4
CREATE OR REPLACE VIEW employee_details AS SELECT emp_id, name, department_id, salary FROM Employees
WHERE department_id = 1;

-- Task 5
DROP VIEW employee_details;
