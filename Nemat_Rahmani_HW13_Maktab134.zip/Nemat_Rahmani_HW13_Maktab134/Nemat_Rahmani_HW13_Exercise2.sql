-- Question 2
-- Task 1
ALTER TABLE Employees ADD date_of_joining DATE;

-- Task 2
UPDATE Employees SET date_of_joining = '2020-01-15' WHERE emp_id = 1;

UPDATE Employees SET date_of_joining = '2019-07-10' WHERE emp_id = 2;

UPDATE Employees SET date_of_joining = '2018-06-20' WHERE emp_id = 3;

UPDATE Employees SET date_of_joining = '2021-03-25' WHERE emp_id = 4;

UPDATE Employees SET date_of_joining = '2022-11-30' WHERE emp_id = 5;

UPDATE Employees SET date_of_joining = '2020-05-15' WHERE emp_id = 6;

UPDATE Employees SET date_of_joining = '2020-09-20' WHERE emp_id = 7;

UPDATE Employees SET date_of_joining = '2021-01-10' WHERE emp_id = 8;

UPDATE Employees SET date_of_joining = '2022-04-05' WHERE emp_id = 9;

UPDATE Employees SET date_of_joining = '2021-07-01' WHERE emp_id = 10;

UPDATE Employees SET date_of_joining = '2021-11-12' WHERE emp_id = 11;

UPDATE Employees SET date_of_joining = '2022-02-28' WHERE emp_id = 12;

UPDATE Employees SET date_of_joining = '2020-08-18' WHERE emp_id = 13;

UPDATE Employees SET date_of_joining = '2021-06-10' WHERE emp_id = 14;

UPDATE Employees SET date_of_joining = '2022-09-17' WHERE emp_id = 15;

UPDATE Employees SET date_of_joining = '2020-01-15' WHERE emp_id = 16;

UPDATE Employees SET date_of_joining = '2019-07-10' WHERE emp_id = 17;

-- Task 3
ALTER TABLE Employees RENAME COLUMN date_of_joining TO joined_on;

-- Task 4
ALTER TABLE Employees ADD CONSTRAINT unique_name_in_department UNIQUE (name, department_id);

-- Task 5
CREATE TABLE Employees_backup AS SELECT * FROM Employees;

-- Task 6: 
-- Risks: 1.Missing Data 2.Data Access (Dependency)
-- Before Deleting A Table: 1.Backuping 2.Informing 3.Dependency Checking 4. Delete Testing (Sensitive Situations)