-- Question 4
-- Task 1
ALTER TABLE Employees ADD is_deleted BOOLEAN DEFAULT FALSE;

-- Task 2
UPDATE Employees SET is_deleted = TRUE WHERE emp_id = 5;

-- Task 3
SELECT * FROM Employees WHERE is_deleted = FALSE;

-- Task 4
SELECT emp_id, name, 
    CASE 
        WHEN is_deleted = TRUE THEN 'Deleted'
        ELSE 'Active'
    END AS status
FROM Employees;

-- Task 5
DELETE FROM Employees WHERE emp_id = 16;
DELETE FROM Employees WHERE emp_id = 17;