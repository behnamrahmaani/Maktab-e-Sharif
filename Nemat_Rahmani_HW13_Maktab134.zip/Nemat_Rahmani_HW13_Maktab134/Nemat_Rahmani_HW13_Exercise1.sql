-- Question 1

CREATE TABLE Employees(
    emp_id INT PRIMARY KEY,
    name VARCHAR(50),
    department_id INT
);

CREATE TABLE Contractors(
    Contractor_id INT PRIMARY KEY,
    name VARCHAR(50),
    department_id INT
);

INSERT INTO Employees (emp_id, name, department_id) VALUES
(1, 'Ali Rezaei', 1),
(2, 'Sara Mohammadi', 2),
(3, 'Mohammad Jafari', 3),
(4, 'Fatemeh Ahmadi', 1),
(5, 'Reza Khodadadi', 4);

INSERT INTO Employees (emp_id, name, department_id) VALUES
(6, 'Mahmoud Khani', 2),
(7, 'Ali Saberi', 3),
(8, 'Sara Mortezaei', 4),
(9, 'Reza Farahani', 1),
(10, 'Niloofar Rezaii', 2),
(11, 'Hassan Gholami', 3),
(12, 'Zahra Mohseni', 1),
(13, 'Mohammad Ali', 4),
(14, 'Mina Karimi', 2),
(15, 'Mojtaba Alavi', 3);

INSERT INTO Employees (emp_id, name, department_id) VALUES
(16, 'Ali Rezaei', 1),
(17, 'Sara Mohammadi', 2);  


INSERT INTO Contractors (Contractor_id, name, department_id) VALUES
(1, 'Kianoosh Esmaili', 1),
(2, 'Niloofar Safavi', 2),
(3, 'Farid Azizi', 3),
(4, 'Mahsa Khorsandi', 4),
(5, 'Sina Rezaei', 1),
(6, 'Ladan Parsa', 2),
(7, 'Amir Hossein Sadeghi', 3),
(8, 'Samira Kiani', 4),
(9, 'Peyman Mohammadi', 1),
(10, 'Leila Jafari', 2),
(11, 'Vahid Asadi', 3),
(12, 'Arezou Shabani', 4),
(13, 'Mohammad Torkaman', 1),
(14, 'Sara Ghasemi', 2);

INSERT INTO Contractors (Contractor_id, name, department_id) VALUES
(15, 'Kianoosh Esmaili', 1),
(16, 'Niloofar Safavi', 2);

-- Task 1
SELECT name FROM Employees UNION SELECT name FROM Contractors;

-- Task 2
SELECT name FROM Employees UNION ALL SELECT name FROM Contractors;

-- Task 3
SELECT name, 'Employee' AS type FROM Employees UNION SELECT name, 'Contractor' AS type FROM Contractors;